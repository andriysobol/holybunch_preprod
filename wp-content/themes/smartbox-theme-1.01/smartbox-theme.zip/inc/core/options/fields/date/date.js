jQuery(document).ready(function($) {
    // set image button
    $( '.oxy-date-field' ).datepicker();
});