<?php
/**
 * Oxygenna.com
 *
 * $Template:: *(TEMPLATE_NAME)*
 * $Copyright:: *(COPYRIGHT)*
 * $Licence:: *(LICENCE)*
 */
require_once CORE_DIR . 'widget.php';

/**
 * Adds Caelus_title widget.
 */
class Smartbox_social extends OxyWidget {

    /**
     * Register widget with WordPress.
     */
    public function __construct() {
        $widget_options = array( 'description' => __( 'Social Icons Widget', THEME_ADMIN_TD) );
        parent::__construct( 'smartbox_social-options.php', false, $name = THEME_NAME . ' - ' . __('Social Icons Widget', THEME_ADMIN_TD), $widget_options );
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        extract( $args );

        $new_window = $this->get_option( 'new_window', $instance, 'on');
        $target = $new_window == 'on' ? 'target="_blank"' : '';

        $output = $before_widget;
        $output.= '<ul class="unstyled inline small-screen-center big social-icons">';
        for( $i = 0 ; $i < 10 ; $i++ ) {
            $social_url = $this->get_option( 'social' . $i . '_url', $instance, '');
            $social_icon = $this->get_option( 'social' . $i . '_icon', $instance, '');

            $output .= empty( $social_icon ) ? '' : '<li><a ' . $target . ' data-iconcolor="' . $this->get_icon_colour( $social_icon ) . '" href="' . $social_url . '"><i class="' . $social_icon . '"></i></a></li>';
        }

        $output.= '</ul>';
        $output.= $after_widget;

        echo $output;
    }

    private function get_icon_colour( $class ) {
        switch( $class ) {
            case 'icon-facebook':
            case 'icon-facebook-sign':
                return '#3b5998';
            break;
            case 'icon-twitter':
            case 'icon-twitter-sign':
                return '#00a0d1';
            break;
            case 'icon-linkedin':
            case 'icon-linkedin-sign':
                return '#5FB0D5';
            break;
            case 'icon-github':
            case 'icon-github-sign':
            case 'icon-github-alt':
            case 'icon-git-fork':
            break;
            case 'icon-pinterest':
            case 'icon-pinterest-sign':
                return '#910101';
            break;
            case 'icon-google-plus':
            case 'icon-google-plus-sign':
                return '#E45135';
            break;

            case 'icon-skype':
                return '#00aff0';
            break;

            case 'icon-youtube-sign':
            case 'icon-youtube':
                return '#c4302b';
            break;

            case 'icon-dropbox':
                return '#3d9ae8';
            break;
            case 'icon-drupal':
                return '#0c76ab';
            break;

            break;
            case 'icon-instagram':
                return '#634d40';
            break;

            case 'icon-share-this-sign':
            break;
            case 'icon-share-this':
            break;

            case 'icon-foursquare':
            case 'icon-foursquare-sign':
                return '#25a0ca';
            break;

            case 'icon-hacker-news':
                return '#ff6600';
            break;
            case 'icon-spotify':
                return '#81b71a';
            break;
            case 'icon-soundcloud':
                return '#ff7700';
            break;
            case 'icon-paypal':
                return '#3b7bbf';
            break;

            case 'icon-reddit':
            break;

            case 'icon-blogger':
            case 'icon-blogger-sign':
                return '#fc4f08';
            break;

            case 'icon-dribbble-sign':
            case 'icon-dribbble':
                return '#ea4c89';
            break;
            case 'icon-evernote-sign':
            case 'icon-evernote':
                return '#5ba525';
            break;

            case 'icon-flickr-sign':
                return '#ff0084';
            break;
            case 'icon-flickr':
                return '#0063dc';
            break;

            case 'icon-forrst-sign':
            case 'icon-forrst':
                return '#5b9a68';
            break;

            case 'icon-delicious':
                case '#205cc0';
            break;
            case 'icon-lastfm':
            case 'icon-lastfm-sign':
                return '#c3000d';
            break;

            case 'icon-picasa-sign':
            break;
            case 'icon-picasa':
            break;

            case 'icon-stack-overflow':
                return '#ef8236';
            break;
            case 'icon-tumblr-sign':
            case 'icon-tumblr':
                return '#34526f';
            break;
            case 'icon-vimeo':
            case 'icon-vimeo-sign':
                return '#86c9ef';
            break;

            case 'icon-wordpress-sign':
                return '#464646';
            break;
            case 'icon-wordpress':
                return '#21759b';
            break;
            case 'icon-yelp-sign':
            case 'icon-yelp':
                return '#c41200';
            break;
        }
    }
}